package com.dicoding.foodapps

data class Food(
    var name: String = "",
    var detail: String = "",
    var photo: Int = 0,
    var titleDetail: String = "",
    var full: String = "",
    var titleCompositionFood: String = "",
    var composition: String = ""


)
